package Ability;

public enum AbilityType {
    Fireblast, Ignite, Execute, Slam, Drain, Deflect, Backstab, Paralysis
}
