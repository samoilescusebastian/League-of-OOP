package character;

public enum CharacterType {
    Knight, Pyromancer, Rogue, Wizard
}
