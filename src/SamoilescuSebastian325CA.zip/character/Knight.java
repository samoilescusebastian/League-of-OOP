package character;

import Ability.Backstab;
import Ability.AbilityType;
import Ability.Paralysis;
import Ability.Execute;
import Ability.Ignite;
import Ability.Drain;
import Ability.Deflect;
import Ability.Slam;
import Ability.Fireblast;
import Location.Land;
import Location.Point;

import static Utils.Constants.KG_HP_PER_LVL;
import static Utils.Constants.KG_INIT_HP;
import static Utils.Constants.LAND_BONUS;
import static Utils.Constants.BS_KNIGHT_BONUS;
import static Utils.Constants.PL_KNIGHT_BONUS;
import static Utils.Constants.DF_KNIGHT_BONUS;
import static Utils.Constants.DR_KNIGHT_BONUS;
import static Utils.Constants.EX_KNIGHT_BONUS;
import static Utils.Constants.SL_KNIGHT_BONUS;
import static Utils.Constants.FB_KNIGHT_BONUS;
import static Utils.Constants.IG_KNIGHT_BONUS;
public final class Knight extends Character {
    public Knight(final Point location) {
        super(KG_INIT_HP, KG_HP_PER_LVL, abilityFactory.createAbility(AbilityType.Execute),
                abilityFactory.createAbility(AbilityType.Slam), location, 'K');
    }
    public void setLocationBonus(final Land cell) {
        baseAbility.setLocationBonus(LAND_BONUS);
        specialAbility.setLocationBonus(LAND_BONUS);
    }
    public void acceptAbility(final Backstab ability) {
        ability.setRacialBonus(BS_KNIGHT_BONUS);
        super.acceptAbility(ability);
    }
    public void acceptAbility(final Paralysis ability) {
        ability.setRacialBonus(PL_KNIGHT_BONUS);
        super.acceptAbility(ability);
    }
    public void acceptAbility(final Deflect ability) {
        ability.setRacialBonus(DF_KNIGHT_BONUS);
        super.acceptAbility(ability);
    }
    public void acceptAbility(final Drain ability) {
        ability.setRacialBonus(DR_KNIGHT_BONUS);
        super.acceptAbility(ability);
    }
    public void acceptAbility(final Execute ability) {
        ability.setRacialBonus(EX_KNIGHT_BONUS);
        super.acceptAbility(ability);
    }
    public void acceptAbility(final Slam ability) {
        ability.setRacialBonus(SL_KNIGHT_BONUS);
        super.acceptAbility(ability);
    }
    public void acceptAbility(final Fireblast ability) {
        ability.setRacialBonus(FB_KNIGHT_BONUS);
        super.acceptAbility(ability);
    }
    public void acceptAbility(final Ignite ability) {
        ability.setRacialBonus(IG_KNIGHT_BONUS);
        super.acceptAbility(ability);
    }
}
