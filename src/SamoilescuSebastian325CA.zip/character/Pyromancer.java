package character;
import Ability.Backstab;
import Ability.AbilityType;
import Ability.Paralysis;
import Ability.Execute;
import Ability.Ignite;
import Ability.Drain;
import Ability.Deflect;
import Ability.Slam;
import Ability.Fireblast;
import Location.Point;
import Location.Volcanic;

import static Utils.Constants.PYRO_HP_PER_LVL;
import static Utils.Constants.PYRO_INIT_HP;
import static Utils.Constants.VOLCANIC_BONUS;
import static Utils.Constants.BS_PYRO_BONUS;
import static Utils.Constants.PL_PYRO_BONUS;
import static Utils.Constants.DF_PYRO_BONUS;
import static Utils.Constants.DR_PYRO_BONUS;
import static Utils.Constants.EX_PYRO_BONUS;
import static Utils.Constants.SL_PYRO_BONUS;
import static Utils.Constants.FB_PYRO_BONUS;
import static Utils.Constants.IG_PYRO_BONUS;
public final class Pyromancer extends Character {

    public Pyromancer(final Point location) {
        super(PYRO_INIT_HP, PYRO_HP_PER_LVL, abilityFactory.createAbility(AbilityType.Fireblast),
                abilityFactory.createAbility(AbilityType.Ignite), location, 'P');

    }
    public void setLocationBonus(final Volcanic cell) {
        baseAbility.setLocationBonus(VOLCANIC_BONUS);
        specialAbility.setLocationBonus(VOLCANIC_BONUS);
    }
    public void acceptAbility(final Backstab ability) {
        ability.setRacialBonus(BS_PYRO_BONUS);
        super.acceptAbility(ability);
    }
    public void acceptAbility(final Paralysis ability) {
        ability.setRacialBonus(PL_PYRO_BONUS);
        super.acceptAbility(ability);
    }
    public void acceptAbility(final Deflect ability) {
        ability.setRacialBonus(DF_PYRO_BONUS);
        super.acceptAbility(ability);
    }
    public void acceptAbility(final Drain ability) {
        ability.setRacialBonus(DR_PYRO_BONUS);
        super.acceptAbility(ability);
    }
    public void acceptAbility(final Execute ability) {
        ability.setRacialBonus(EX_PYRO_BONUS);
        super.acceptAbility(ability);
    }
    public void acceptAbility(final Slam ability) {
        ability.setRacialBonus(SL_PYRO_BONUS);
        super.acceptAbility(ability);
    }
    public void acceptAbility(final Fireblast ability) {
        ability.setRacialBonus(FB_PYRO_BONUS);
        super.acceptAbility(ability);
    }
    public void acceptAbility(final Ignite ability) {
        ability.setRacialBonus(IG_PYRO_BONUS);
        super.acceptAbility(ability);
    }
}
