package character;

import Ability.Backstab;
import Ability.AbilityType;
import Ability.Paralysis;
import Ability.Execute;
import Ability.Ignite;
import Ability.Drain;
import Ability.Deflect;
import Ability.Slam;
import Ability.Fireblast;
import Location.Point;
import Location.Woods;

import static Utils.Constants.ROG_HP_PER_LVL;
import static Utils.Constants.ROG_INIT_HP;
import static Utils.Constants.WOODS_BONUS;
import static Utils.Constants.BS_ROGUE_BONUS;
import static Utils.Constants.SL_ROGUE_BONUS;
import static Utils.Constants.DR_ROGUE_BONUS;
import static Utils.Constants.DF_ROGUE_BONUS;
import static Utils.Constants.IG_ROGUE_BONUS;
import static Utils.Constants.PL_ROGUE_BONUS;
import static Utils.Constants.EX_ROGUE_BONUS;
import static Utils.Constants.FB_ROGUE_BONUS;
public final class Rogue extends Character {
    public Rogue(final Point location) {
        super(ROG_INIT_HP, ROG_HP_PER_LVL, abilityFactory.createAbility(AbilityType.Backstab),
                abilityFactory.createAbility(AbilityType.Paralysis), location, 'R');
    }
    public void setLocationBonus(final Woods cell) {
        baseAbility.setLocationBonus(WOODS_BONUS);
        specialAbility.setLocationBonus(WOODS_BONUS);
        ((Backstab) baseAbility).setCritical(true);
        ((Paralysis) specialAbility).addOvertimeBonus();
    }
    public void acceptAbility(final Backstab ability) {
        ability.setRacialBonus(BS_ROGUE_BONUS);
        super.acceptAbility(ability);
    }
    public void acceptAbility(final Paralysis ability) {
        ability.setRacialBonus(PL_ROGUE_BONUS);
        super.acceptAbility(ability);
    }
    public void acceptAbility(final Deflect ability) {
        ability.setRacialBonus(DF_ROGUE_BONUS);
        super.acceptAbility(ability);
    }
    public void acceptAbility(final Drain ability) {
        ability.setRacialBonus(DR_ROGUE_BONUS);
        super.acceptAbility(ability);
    }
    public void acceptAbility(final Execute ability) {
        ability.setRacialBonus(EX_ROGUE_BONUS);
        super.acceptAbility(ability);
    }
    public void acceptAbility(final Slam ability) {
        ability.setRacialBonus(SL_ROGUE_BONUS);
        super.acceptAbility(ability);
    }
    public void acceptAbility(final Fireblast ability) {
        ability.setRacialBonus(FB_ROGUE_BONUS);
        super.acceptAbility(ability);
    }
    public void acceptAbility(final Ignite ability) {
        ability.setRacialBonus(IG_ROGUE_BONUS);
        super.acceptAbility(ability);
    }
}
